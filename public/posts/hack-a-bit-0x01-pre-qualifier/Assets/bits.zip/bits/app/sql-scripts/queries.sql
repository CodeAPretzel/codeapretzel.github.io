use hack_a_bit;

SELECT * from email_tokens;

SELECT * from email_tokens WHERE token="adfe25220991bbe10af7d20d95a2c27db099822a";
DELETE FROM email_tokens WHERE token="test";


